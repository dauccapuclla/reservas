---
name: Residential Operations System
colors:
  surface: '#faf8ff'
  surface-dim: '#dad9e1'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3fa'
  surface-container: '#eeedf4'
  surface-container-high: '#e9e7ef'
  surface-container-highest: '#e3e1e9'
  on-surface: '#1a1b21'
  on-surface-variant: '#444651'
  inverse-surface: '#2f3036'
  inverse-on-surface: '#f1f0f7'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#585f6a'
  on-secondary: '#ffffff'
  secondary-container: '#dce3f0'
  on-secondary-container: '#5e6570'
  tertiary: '#4b1c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6e2c00'
  on-tertiary-container: '#f39461'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#dce3f0'
  secondary-fixed-dim: '#c0c7d3'
  on-secondary-fixed: '#151c25'
  on-secondary-fixed-variant: '#404752'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#773205'
  background: '#faf8ff'
  on-background: '#1a1b21'
  surface-variant: '#e3e1e9'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system is engineered for the high-stakes environment of residential management, where clarity and trust are paramount. The aesthetic merges the approachable usability of high-end consumer platforms with the rigorous efficiency of modern developer tools.

The design style is **Corporate Minimalism**. It prioritizes heavy white space, intentional structural alignment, and a "content-first" hierarchy. By stripping away decorative clutter, the system ensures that complex data—such as maintenance schedules, amenity bookings, and tenant communications—remains scannable and actionable. The emotional goal is to provide a sense of calm control for property managers and a premium, reliable experience for residents.

## Colors

The palette is anchored by a commanding **Deep Blue**, signifying stability and corporate authority. This is balanced by a high-ratio of white and neutral grays to maintain a "breathable" interface that doesn't overwhelm the user during long sessions.

- **Primary (#1E3A8A):** Used for primary actions, active navigation states, and brand identifiers.
- **Secondary Gray (#9CA3AF):** Reserved for non-critical iconography, disabled states, and secondary metadata.
- **Surface Grays (#F3F4F6):** Utilized for subtle background grouping, input fields, and page-level sectioning to create depth without relying on heavy borders.
- **Success/Warning/Error:** Use standard semantic tones (Emerald 600, Amber 500, Rose 600) but desaturate them slightly to fit the professional tone.

## Typography

This design system utilizes **Inter** exclusively to ensure maximum legibility and a systematic, utilitarian feel. The hierarchy is strictly enforced through weight and tracking adjustments rather than excessive color changes.

- **Headlines:** Use tighter letter-spacing for large titles to create a "locked-in," professional look.
- **Body Text:** Standard weight is 400. Use 500 (Medium) for emphasis within paragraphs to avoid the visual heaviness of Bold.
- **Labels:** Small labels use uppercase styling with increased tracking to differentiate them from body copy in dense data views.
- **Responsive Note:** On mobile, `headline-lg` should scale down to `24px` to maintain visual balance within narrow viewports.

## Layout & Spacing

The layout philosophy follows a **Modular Grid** system. On desktop, content is typically housed within a 12-column grid with generous 24px gutters to prevent information density from feeling claustrophobic.

- **Desktop:** 12 columns, 48px outer margins. Use a fixed-width central container (1440px) for standard pages; use fluid-width for complex dashboard views.
- **Tablet:** 8 columns, 32px outer margins.
- **Mobile:** 4 columns, 16px outer margins.
- **Rhythm:** All vertical spacing should be a multiple of 4px. Use `32px` (stack-lg) between major sections and `16px` (stack-md) between related elements within a card.

## Elevation & Depth

To maintain a minimal aesthetic, this design system uses **Tonal Layering** and **Ambient Shadows** instead of heavy borders. Depth is used to indicate interactivity and importance.

- **Level 0 (Background):** The base layer is white or the light gray surface color.
- **Level 1 (Cards/Containers):** Elements are lifted slightly using a very soft, diffused shadow: `0px 4px 12px rgba(0, 0, 0, 0.05)`.
- **Level 2 (Modals/Popovers):** Higher elevation with a more pronounced shadow: `0px 12px 32px rgba(0, 0, 0, 0.1)`.
- **Contrast:** High-priority items (like a "Book Now" CTA) use the Deep Blue primary color to create "visual elevation" through color weight rather than shadow.

## Shapes

The shape language is characterized by **Soft Geometric** forms. This strikes a balance between the precision of a corporate tool and the friendliness of a residential app.

- **Standard Elements:** Buttons and input fields use a `0.5rem` (8px) radius.
- **Large Containers:** Cards and modals use a `rounded-lg` or `rounded-xl` setting (16px to 24px) to create a soft, premium "frame" around content.
- **Icons:** Use icons with a consistent stroke weight (2px) and slightly rounded caps to match the UI's geometry.

## Components

### Buttons
- **Primary:** Solid Deep Blue background, white text. No border.
- **Secondary:** Light Gray background, Deep Blue text.
- **Ghost:** No background, Secondary Gray text; shifts to Primary on hover.

### Input Fields
- Use a subtle 1px border (#E5E7EB) and a 12px internal padding. On focus, the border transitions to Primary Deep Blue with a 2px soft glow.

### Badges (Status Indicators)
- Use "Pill" shapes with low-opacity background tints of the semantic colors (e.g., Light Green background with Dark Green text for "Available"). This ensures they are visible but not distracting.

### Cards
- White background, 16px corner radius, and the "Level 1" ambient shadow. Padding should be generous (minimum 24px).

### Lists
- Use "border-bottom" separators in #F3F4F6 for data lists. Include a hover state that applies a subtle gray background to indicate row interactivity.

### Specific Components
- **Amenity Calendar:** A clean, grid-based view with "Blocked" time slots represented by subtle diagonal patterns rather than solid dark colors.
- **Notification Toast:** Positioned at top-right, utilizing high-contrast icons to denote urgency.